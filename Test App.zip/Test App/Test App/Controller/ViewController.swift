//
//  ViewController.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var lastSyncLbl: UILabel!
    
    @IBOutlet weak var totalPriceLbl: UILabel!
    
    var totalPrice = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        registerXib()
        getData()
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("InternetConnected"), object: nil)

    }
    
    
}
extension ViewController{
    func getData(){
        Service.shareInstance.getAllMovieData { (products, error) in
            if(error==nil){
                for obj in products!{
                    DBManager.shared.addProductToDB(product: obj)
                }
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "h:mm a MM/dd/yyyy"
                dateFormatter.timeZone = .current
                UserDefaults.standard.setValue( dateFormatter.string(from:Date()), forKey: "lastSync")
                
                self.setupUI()
            }
            else{
                self.setupUI()
            }
        }
        
    }
    
    func registerXib(){
        tableView.register(UINib(nibName: "ProductsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductsTableViewCell")
    }
    
    @objc func methodOfReceivedNotification(notification: Notification) {
        getData()
    }
    
    func loadProducts(){
        DBManager.shared.fetchProductsFromDB { message in
            if message == "Success"{
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    func setupUI(){
        DispatchQueue.main.async {
            self.lastSyncLbl.text = "Last Sync at: \n \(UserDefaults.standard.value(forKey: "lastSync") ?? Date())"
            self.totalPriceLbl.text = "Total Price: $ \(self.totalPrice.rounded())"
            self.loadProducts()
        }
    }
    

}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DBManager.shared.dataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductsTableViewCell") as! ProductsTableViewCell
        
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.clear
        cell.selectedBackgroundView = backgroundView
        let dataModel = DBManager.shared.dataArray[indexPath.row]
        cell.titleLabel.text = dataModel.title
        cell.priceLbl.text = "Price: $ \(dataModel.price)"
        cell.buyTapped = {
            self.totalPrice = self.totalPrice + dataModel.price
            self.totalPriceLbl.text = "Total Price: $ \(self.totalPrice.rounded())"
        }
        return cell
    }
    
    
}
