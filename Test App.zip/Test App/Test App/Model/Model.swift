//
//  Model.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import Foundation

class ResultsModel: Decodable {
    
    var results = [ProductModel]()
    
    init(results: [ProductModel]) {
        self.results = results
    }
}

class ProductModel: Decodable {
    
    var id : Int?
    var trackName: String?
    var title : String?
    var price : Double?
    var category : String?
    var image : String?
    
    init(id : Int ,trackName : String, title : String, price : Double, category : String, image : String){
        self.id = id
        self.trackName = trackName
        self.title = title
        self.price = price
        self.category = category
        self.image = image
    }
}
