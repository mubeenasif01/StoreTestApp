//
//  Product+CoreDataClass.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//
//

import Foundation
import CoreData


public class Product: NSManagedObject {

}
