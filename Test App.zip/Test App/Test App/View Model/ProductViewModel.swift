//
//  ProductViewModel.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import Foundation

class ProductViewModel: NSObject {
    
    var id : Int?
    var trackName: String?
    var title : String?
    var price : Double?
    var category : String?
    var image : String?
    
    // D I
    
    init(product : ProductModel){
        self.trackName      = product.trackName
        self.title          = product.title
        self.price          = product.price
        self.category       = product.category
        self.image          = product.image
    }
}
