//
//  Service.swift
//  Test App
//
//  Created by Mubeen Asif on 23/01/2022.
//

import Foundation

class Service: NSObject {
    
    static let shareInstance = Service()
    
    let urlString = "https://fakestoreapi.com/products"
    
    func getAllMovieData(completion: @escaping([ProductModel]?, Error?) -> ()){
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let err = error{
                completion(nil,err)
                print("Loading data error: \(err.localizedDescription)")
            }else{
                guard let data = data else { return }
                do{
                    let jsonDecoder = JSONDecoder()
                    var arrMovieData = [ProductModel]()
                    let results = try jsonDecoder.decode([ProductModel].self, from: data)
                    for product in results{
                        arrMovieData.append(ProductModel(id: product.id ?? 0,
                                                         trackName: product.trackName ?? "",
                                                         title: product.title ?? "",
                                                         price: product.price ?? 0.0,
                                                         category: product.category ?? "",
                                                         image: product.image ?? ""))
                    }
                    completion(arrMovieData, nil)
                    
                    
                }catch let jsonErr{
                    print("json error : \(jsonErr.localizedDescription)")
                }
            }
        }.resume()
    }
    
    
    
}
